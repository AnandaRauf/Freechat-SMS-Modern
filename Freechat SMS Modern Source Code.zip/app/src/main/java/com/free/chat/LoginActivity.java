package com.free.chat;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.app.Activity;
import android.widget.LinearLayout;
import android.widget.EditText;
import android.widget.Button;
import android.webkit.WebView;
import android.webkit.WebSettings;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import android.content.Intent;
import android.net.Uri;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import java.util.HashMap;
import android.content.SharedPreferences;
import android.view.View;

public class LoginActivity extends Activity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private String Username = "";
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private EditText edittext5;
	private LinearLayout linear23;
	private Button logout;
	private Button contact;
	private LinearLayout linear16;
	private LinearLayout linear18;
	private LinearLayout linear19;
	private LinearLayout linear21;
	private Button fd;
	private WebView webview1;
	private Button sendmessage;
	private EditText edittext6;
	private EditText message;
	
	private FirebaseAuth fc;
	private OnCompleteListener<AuthResult> _fc_create_user_listener;
	private OnCompleteListener<AuthResult> _fc_sign_in_listener;
	private OnCompleteListener<Void> _fc_reset_password_listener;
	private Intent in = new Intent();
	private DatabaseReference freechat_data = _firebase.getReference("freechat data");
	private ChildEventListener _freechat_data_child_listener;
	private SharedPreferences user_freechat;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.login);
		initialize();
		initializeLogic();
	}
	
	private void initialize() {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		edittext5 = (EditText) findViewById(R.id.edittext5);
		linear23 = (LinearLayout) findViewById(R.id.linear23);
		logout = (Button) findViewById(R.id.logout);
		contact = (Button) findViewById(R.id.contact);
		linear16 = (LinearLayout) findViewById(R.id.linear16);
		linear18 = (LinearLayout) findViewById(R.id.linear18);
		linear19 = (LinearLayout) findViewById(R.id.linear19);
		linear21 = (LinearLayout) findViewById(R.id.linear21);
		fd = (Button) findViewById(R.id.fd);
		webview1 = (WebView) findViewById(R.id.webview1);
		webview1.getSettings().setJavaScriptEnabled(true);
		webview1.getSettings().setSupportZoom(true);
		sendmessage = (Button) findViewById(R.id.sendmessage);
		edittext6 = (EditText) findViewById(R.id.edittext6);
		message = (EditText) findViewById(R.id.message);
		fc = FirebaseAuth.getInstance();
		user_freechat = getSharedPreferences("user_freechat", Activity.MODE_PRIVATE);
		
		logout.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				FirebaseAuth.getInstance().signOut();
				SketchwareUtil.showMessage(getApplicationContext(), "Logout succeed");
				in.setClass(getApplicationContext(), MainActivity.class);
				startActivity(in);
				finish();
			}
		});
		
		contact.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				in.setClass(getApplicationContext(), ContactActivity.class);
				startActivity(in);
				finish();
			}
		});
		
		fd.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				webview1.loadUrl("https://www.instagram.com/anandarauf08");
			}
		});
		
		webview1.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				super.onPageFinished(_param1, _param2);
			}
		});
		
		sendmessage.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				in.setAction(Intent.ACTION_VIEW);
				in.setData(Uri.parse("sms:".concat(edittext6.getText().toString())));
				in.putExtra("sms_body", edittext5.getText().toString());
				startActivity(in);
			}
		});
		
		_freechat_data_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		freechat_data.addChildEventListener(_freechat_data_child_listener);
		
		_fc_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_fc_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_fc_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	private void initializeLogic() {
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
