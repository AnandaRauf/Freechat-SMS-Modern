package com.free.chat;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.app.Activity;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.content.Intent;
import android.net.Uri;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import android.media.SoundPool;
import java.util.Timer;
import java.util.TimerTask;
import android.view.View;

public class MainActivity extends Activity {
	
	private Timer _timer = new Timer();
	
	private LinearLayout linear6;
	private LinearLayout linear7;
	private TextView eml;
	private EditText email;
	private TextView pwd;
	private EditText password;
	private Button login;
	private TextView newaccount;
	private TextView forgetpassword;
	private TextView textview4;
	
	private Intent in = new Intent();
	private FirebaseAuth fc;
	private OnCompleteListener<AuthResult> _fc_create_user_listener;
	private OnCompleteListener<AuthResult> _fc_sign_in_listener;
	private OnCompleteListener<Void> _fc_reset_password_listener;
	private SoundPool sound;
	private TimerTask timerliad;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize();
		initializeLogic();
	}
	
	private void initialize() {
		
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		eml = (TextView) findViewById(R.id.eml);
		email = (EditText) findViewById(R.id.email);
		pwd = (TextView) findViewById(R.id.pwd);
		password = (EditText) findViewById(R.id.password);
		login = (Button) findViewById(R.id.login);
		newaccount = (TextView) findViewById(R.id.newaccount);
		forgetpassword = (TextView) findViewById(R.id.forgetpassword);
		textview4 = (TextView) findViewById(R.id.textview4);
		fc = FirebaseAuth.getInstance();
		
		login.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				if (email.getText().toString().equals("") || password.getText().toString().equals("")) {
					SketchwareUtil.showMessage(getApplicationContext(), "Sorry you not entered email and password");
				}
				else {
					fc.signInWithEmailAndPassword(email.getText().toString(), password.getText().toString()).addOnCompleteListener(MainActivity.this, _fc_sign_in_listener);
					in.setClass(getApplicationContext(), LoginActivity.class);
					SketchwareUtil.showMessage(getApplicationContext(), "Welcome ^•^");
					startActivity(in);
					finish();
				}
			}
		});
		
		newaccount.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				in.setClass(getApplicationContext(), RegisterActivity.class);
				startActivity(in);
				finish();
			}
		});
		
		forgetpassword.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				in.setClass(getApplicationContext(), ForgetpasswordActivity.class);
				startActivity(in);
				finish();
			}
		});
		
		_fc_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_fc_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_fc_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	private void initializeLogic() {
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
